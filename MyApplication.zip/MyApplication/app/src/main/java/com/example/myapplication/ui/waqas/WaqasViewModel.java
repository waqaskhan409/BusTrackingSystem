package com.example.myapplication.ui.waqas;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;

import com.example.myapplication.ui.waqas.Model.ModelReposotry;
import com.example.myapplication.ui.waqas.Model.Note;

import java.util.List;

import androidx.lifecycle.LiveData;

public class WaqasViewModel extends AndroidViewModel {
    private ModelReposotry modelReposotry;
    private LiveData<List<Note>> allNotes;

    public WaqasViewModel(@NonNull Application application) {
        super(application);
        modelReposotry = new ModelReposotry(application);
        allNotes = modelReposotry.getAllNotes();

    }
    public void insert(Note note){
        modelReposotry.insert(note);
    }
    public void updare(Note note){
        modelReposotry.update(note);
    }
    public void delete(Note note){
        modelReposotry.delete(note);
    }
    public void deleteAll(){
        modelReposotry.deleteAllNotes();
    }
    public LiveData<List<Note>> getAllNotes(){
        return allNotes;
    }

    // TODO: Implement the ViewModel
}
